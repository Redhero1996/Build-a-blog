<?php $__env->startSection('title', '| About me'); ?>
<?php $__env->startSection('content'); ?>


      <div class="row">
        <div class="col-md-12">
          <h1>About Me</h1>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis aspernatur quas quibusdam veniam sunt animi, est quos optio explicabo deleniti inventore unde minus, tempore enim ratione praesentium, cumque, dolores nesciunt?</p>
        </div>
      </div>
	
    <!-- end of .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>