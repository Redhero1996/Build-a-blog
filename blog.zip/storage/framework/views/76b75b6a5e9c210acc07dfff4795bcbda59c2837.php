<?php $__env->startSection('title', '| Blog'); ?>

<?php $__env->startSection('content'); ?>
	<div class="row ">
		<div class="col-md-8 col-md-offset-2">
			<h1>Blog</h1>
		</div>
	</div>
	<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
		<?php
		  $created_at = new DateTime($post->created_at);
		  $time_zone = new DateTimeZone('Asia/Ho_Chi_Minh');
		  $created_at->setTimezone($time_zone);
		?>

		<div class="row ">
			<div class="col-md-8 col-md-offset-2">
				<h2><?php echo e($post->title); ?></h2>
				<small><strong><i>Publish: <?php echo e($created_at->format('M j, Y')); ?></i></strong></small>

				<p><?php echo e(substr($post->body, 0, 255)); ?><?php echo e(strlen($post->body) > 255 ? '...' : ""); ?></p>

				<a href="<?php echo e(route('blog.single', $post->id)); ?>" class="btn btn-primary">Read more</a>

				<hr>
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<div class="row">
		<div class="col-md-12">
			<div class="text-center">
				<?php echo $posts->links(); ?>

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>