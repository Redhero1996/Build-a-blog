<?php $__env->startSection('title', '| Create New Post'); ?>
<?php $__env->startSection('stylesheets'); ?>
	<?php echo Html::style('css/parsley.css'); ?>

	<?php echo Html::style('css/select2.min.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	  <div class="col-md-8 col-md-offset-2">
	    <h1>Create New Post</h1>
	    <hr>
	    <form data-parsley-validate method="POST" action="<?php echo e(route('posts.store')); ?>">
	    	<?php echo e(csrf_field()); ?>

	    	
	      <div class="form-group">
	        <label for="title">Title:</label>
	        <input id="title" name="title" class="form-control" required="">
			
	      </div>

	      <div class="form-group">
	        <label for="slug">Slug:</label>
	        <input type="text" id="slug" name="slug" rows="10" class="form-control" required=""></input>
	      </div> 

	      <div class="form-group">
	        <label for="category_id">Category:</label>
	        <select class="form-control" name="category_id">
	        	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        		<option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
	        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	        </select>
	      </div>

	      <div class="form-group">
	        <label for="tags">Tag:</label>
	        <select class="form-control select2-multi" name="tags[]" multiple="multiple">
	        	<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        		<option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
	        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	        </select>
	      </div>

	      <div class="form-group">
	        <label for="body">Post Body:</label>
	        <textarea id="body" name="body" rows="10" class="form-control" required=""></textarea>
	      </div>

	      <input type="submit" value="Create Post" class="btn btn-info btn-lg btn-block">
	     
	    </form>
	  </div>
	</div>﻿
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<?php echo Html::script('js/parsley.min.js'); ?>

	<?php echo Html::script('js/select2.min.js'); ?>


	<script type="text/javascript">
		$('.select2-multi').select2();
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>