<?php $__env->startSection('title', '| Edit Blog Post'); ?>

<?php $__env->startSection('stylesheets'); ?>
	<?php echo Html::style('css/select2.min.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
			<?php echo Form::model($post, ['route' => ['posts.update', $post->id ], 'method' => 'PUT']); ?>


			<div class="col-md-8">			
				

				<?php echo Form::label('title', 'Title:'); ?>

				<?php echo e(Form::text('title', null, ['class' => 'form-control input-lg'])); ?>


				<?php echo Form::label('slug', 'Slug:', ['class' => 'form-spacing-top']); ?>

				<?php echo e(Form::text('slug', null, ['class' => 'form-control input-lg'])); ?>


				<?php echo Form::label('category_id', 'Category:', ['class' => 'form-spacing-top']); ?>

				<?php echo Form::select('category_id', $categories, null, ['class' => 'form-control']); ?>


				<?php echo Form::label('tags', 'Tag:', ['class' => 'form-spacing-top']); ?>

				<?php echo Form::select('tags[]', $tags, null, ['class' => 'form-control select2-multi', 'multiple' => 'multiple']); ?>


				<?php echo Form::label('body', 'Body:', ['class' => 'form-spacing-top']); ?>

				<?php echo e(Form::textarea('body', null, ['class' => 'form-control'])); ?>

			</div>

			<div class="col-md-4">
				<div class="well">
					<dl class="dl-horizontal">
						<label> Url:</label>
						<a href="<?php echo e(url($post->slug)); ?>"> <?php echo e(url($post->slug)); ?> </a>
					</dl>

					<dl class="dl-horizontal">
						<?php
							$created_at = new DateTime($post->created_at);
							$updated_at = new DateTime($post->updated_at);
							$time_zone = new DateTimeZone('Asia/Ho_Chi_Minh');
							$created_at->setTimezone($time_zone);
							$updated_at->setTimezone($time_zone);
						?>
						
						<label> Created At:</label>
						<p><?php echo e($created_at->format('M j, Y h:ia')); ?></p>
					</dl>

					<dl class="dl-horizontal">
						<label> Last Updated:</label>
						<p><?php echo e($updated_at->format('M j, Y h:ia')); ?></p>
					</dl>
					<hr>
					<div class="row">
						<div class="col-sm-6">
							<a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-danger btn-block">Cancel</a>
						</div>
						<div class="col-sm-6">
							<input type="submit" value="Save Changes" class="btn btn-success btn-block">
							
						</div>
					</div>
				</div>			
			</div>
		<?php echo Form::close(); ?>

	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<?php echo Html::script('js/select2.min.js'); ?>

	<script type="text/javascript">
		$('.select2-multi').select2();
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>